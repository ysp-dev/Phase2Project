'use strict';
/* Main application controller — state, tabs, events, localStorage */

(function () {
  const LS_ITEMS = 'hd2_items_v2';
  const LS_PREFS = 'hd2_prefs_v1';

  // ── State ────────────────────────────────────────────────────────────────────
  const state = {
    tab:     'gantt',
    items:   [],
    layout:  'side',
    fTask:   '전체',
    fCat:    '전체',
    fStatus: '전체',
    query:   '',
  };
  let temporalTimer = null;
  let ganttNeedsRefresh = false;

  // ── Persistence ───────────────────────────────────────────────────────────────
  function seedCopy() {
    return window.PROJECT_DATA.SEED_ITEMS.map(it => Object.assign({}, it));
  }

  // 저장된 항목이 렌더러가 가정하는 구조/enum 값을 갖췄는지 검증.
  // 예전 스키마·손상 데이터로 인한 빈 화면/예외를 막고, 실패 시 seed로 복구.
  function isValidItems(arr) {
    if (!Array.isArray(arr)) return false;
    const D = window.PROJECT_DATA;
    return arr.every(it =>
      it && typeof it === 'object' &&
      typeof it.id === 'string' &&
      typeof it.title === 'string' &&
      typeof it.updatedAt === 'string' &&
      D.CATEGORY_STYLE[it.category] &&   // buildCatTag 에서 .fg 접근 → 필수
      D.STATUS_STYLE[it.status] &&       // 상태 배지 스타일 매핑 → 필수
      D.PRIORITY_STYLE[it.priority]      // 중요도 배지 스타일 매핑 → 필수
    );
  }

  function loadItems() {
    try {
      const raw = localStorage.getItem(LS_ITEMS);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (isValidItems(parsed)) return parsed;
      }
    } catch (e) {}
    return seedCopy();
  }

  function saveItems() {
    try { localStorage.setItem(LS_ITEMS, JSON.stringify(state.items)); } catch (e) {}
  }

  function loadPrefs() {
    try {
      const raw = localStorage.getItem(LS_PREFS);
      if (raw) {
        const p = JSON.parse(raw);
        // 탭은 복원하지 않음 — 앱은 항상 간트차트(최초 화면)로 시작
        if (p.layout) state.layout = p.layout;
      }
    } catch (e) {}
  }

  function savePrefs() {
    try {
      localStorage.setItem(LS_PREFS, JSON.stringify({ tab: state.tab, layout: state.layout }));
    } catch (e) {}
  }

  // ── Render ────────────────────────────────────────────────────────────────────
  function renderHeader() {
    const M = window.PROJECT_DATA.META;
    const titleEl = document.getElementById('brand-title');
    const DEPT = '여신IT개발부';
    if (M.title.startsWith(DEPT)) {
      // '여신IT개발부'만 색상 차별화
      titleEl.innerHTML = '';
      const dept = document.createElement('span');
      dept.className = 'brand-dept';
      dept.textContent = DEPT;
      titleEl.appendChild(dept);
      titleEl.appendChild(document.createTextNode(M.title.slice(DEPT.length)));
    } else {
      titleEl.textContent = M.title;
    }
    const badge = document.getElementById('items-count-badge');
    if (badge) badge.textContent = state.items.length;

    renderHeaderProgress();
  }

  function renderHeaderProgress() {
    const el = document.getElementById('header-progress');
    if (!el) return;
    const today  = window.PROJECT_DATA.TODAY_INDEX;
    const openMs = window.PROJECT_DATA.MILESTONES.find(m => m.id === 'ms-open');
    const total  = openMs ? openMs.index : window.PROJECT_DATA.TOTAL_MONTHS;
    const pct    = Math.min(100, Math.round(today / total * 100));
    const done   = Math.floor(today);
    const r      = 17;
    const circ   = 2 * Math.PI * r;
    const arc    = circ * pct / 100;
    el.innerHTML =
      `<div class="hprog-ring-wrap">` +
        `<svg class="hprog-ring" viewBox="0 0 44 44" aria-hidden="true">` +
          `<circle class="hprog-ring-bg"   cx="22" cy="22" r="${r}"/>` +
          `<circle class="hprog-ring-fill" cx="22" cy="22" r="${r}"` +
            ` stroke-dasharray="${arc.toFixed(2)} ${(circ - arc).toFixed(2)}"/>` +
        `</svg>` +
        `<span class="hprog-pct">${pct}%</span>` +
      `</div>` +
      `<div class="hprog-info">` +
        `<span class="hprog-label">전체 진행률</span>` +
        `<span class="hprog-detail">${done}개월 / ${Math.round(total)}개월</span>` +
      `</div>`;
  }

  function renderGanttTab(force) {
    const container = document.getElementById('gantt-container');
    if (!container) return;
    if (force || ganttNeedsRefresh || !container.hasChildNodes()) {
      renderGantt(container);
      ganttNeedsRefresh = false;
    }
  }

  function renderTab() {
    // 패널: active 클래스 + hidden 속성 동기화
    document.querySelectorAll('.tab-panel').forEach(p => {
      const isActive = p.id === 'panel-' + state.tab;
      p.classList.toggle('active', isActive);
      p.hidden = !isActive;
    });
    // 탭 버튼: active 클래스 + aria-selected + 포커스 순서(roving tabindex)
    document.querySelectorAll('.tab-btn').forEach(b => {
      const isActive = b.dataset.tab === state.tab;
      b.classList.toggle('active', isActive);
      b.setAttribute('aria-selected', isActive ? 'true' : 'false');
      b.tabIndex = isActive ? 0 : -1;
    });

    if (state.tab === 'dashboard') {
      renderDashboard(document.getElementById('panel-dashboard'), state.items);
    } else if (state.tab === 'gantt') {
      renderGanttTab(false);
    } else if (state.tab === 'items') {
      renderItemsTab();
    }

    renderHeader();
    savePrefs();
  }

  function renderItemsTab() {
    const container = document.getElementById('panel-items');
    if (!container) return;
    renderItems(container, state.items, {
      layout:   state.layout,
      fTask:    state.fTask,
      fCat:     state.fCat,
      fStatus:  state.fStatus,
      query:    state.query,
      onAdd:    addItem,
      onUpdate: updateItem,
      onDelete: deleteItem,
    });
  }

  // ── CRUD ──────────────────────────────────────────────────────────────────────
  function addItem(item) {
    state.items = [item, ...state.items];
    saveItems();
    renderTab();
  }

  function updateItem(item) {
    state.items = state.items.map(x => x.id === item.id ? item : x);
    saveItems();
    renderTab();
  }

  function deleteItem(id) {
    state.items = state.items.filter(x => x.id !== id);
    saveItems();
    renderTab();
  }

  // ── 기준일/시각 자동 갱신 ───────────────────────────────────────────────────
  function refreshTemporalState() {
    if (window.PROJECT_DATA && typeof window.PROJECT_DATA.refreshToday === 'function') {
      window.PROJECT_DATA.refreshToday();
    }

    // 기준일 라벨의 시각은 분 단위라, 보이지 않는 동안에도 다음 간트 진입 시 새로 그린다.
    ganttNeedsRefresh = true;
    renderHeader();
    if (state.tab === 'gantt') renderGanttTab(true);
  }

  function scheduleTemporalRefresh() {
    const now = new Date();
    const delay = 60000 - (now.getSeconds() * 1000 + now.getMilliseconds()) + 50;
    temporalTimer = setTimeout(() => {
      refreshTemporalState();
      scheduleTemporalRefresh();
    }, Math.max(1000, delay));
  }

  function startTemporalRefresh() {
    if (temporalTimer) return;
    scheduleTemporalRefresh();
    window.addEventListener('focus', refreshTemporalState);
    window.addEventListener('pageshow', refreshTemporalState);
    document.addEventListener('visibilitychange', () => {
      if (!document.hidden) refreshTemporalState();
    });
  }

  // ── Events ────────────────────────────────────────────────────────────────────
  function bindEvents() {
    document.addEventListener('click', e => {
      const tabBtn = e.target.closest('.tab-btn');
      if (tabBtn && tabBtn.dataset.tab) {
        state.tab = tabBtn.dataset.tab;
        renderTab();
      }
    });

    document.addEventListener('items:filter', e => {
      const { key, val } = e.detail;
      state[key] = val;
      renderItemsTab();
      if (key === 'layout') savePrefs(); // 레이아웃 변경 즉시 영속화
    });
    document.addEventListener('items:resort', () => renderItemsTab());
    document.addEventListener('items:reset', () => {
      state.items = seedCopy();
      localStorage.removeItem(LS_ITEMS);
      renderTab();
    });
    document.addEventListener('app:switch-tab', e => {
      state.tab = e.detail;
      renderTab();
    });
    document.addEventListener('keydown', e => {
      if (e.key === 'Escape') {
        const overlay = document.getElementById('modal-overlay');
        if (overlay && !overlay.classList.contains('hidden')) {
          overlay.classList.add('hidden');
          overlay.innerHTML = '';
        }
      }
    });
  }

  // ── Init ─────────────────────────────────────────────────────────────────────
  function init() {
    state.items = loadItems();
    loadPrefs();
    bindEvents();
    renderTab();
    startTemporalRefresh();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
